# Zurich Surfers (Unity C# Starter)

Um protótipo original de endless runner 3D ambientado em uma versão fictícia de Zurique, Suíça. Este pacote contém scripts C# e instruções — não inclui assets de terceiros, cenas Unity prontas, música, nem um APK compilado.

## Recursos incluídos
- Corrida automática para frente
- Três faixas e troca de faixa
- Pulo e deslize
- Controles por teclado para testar no Editor
- Gestos de deslizar na tela para Android
- Moedas coletáveis e pontuação
- Obstáculos e trens simples
- Câmera seguindo o jogador
- Spawner básico de obstáculos e moedas

## Compatibilidade
Criado para projetos 3D do Unity usando C#. O pacote foi pensado como base inicial e pode precisar de pequenos ajustes conforme a versão do Unity e a configuração do projeto.

## Instalação no Android usando GitHub
1. Baixe e extraia este ZIP.
2. Crie um projeto **3D** no Unity Editor (a criação e compilação do jogo exige acesso ao Unity Editor; o GitHub Mobile sozinho não compila um projeto Unity).
3. Copie a pasta `Assets/Scripts/` para a pasta `Assets/` do projeto Unity.
4. Crie uma cena com um chão, um personagem com `CharacterController` e uma câmera.
5. Adicione `PlayerRunner` ao personagem e `CameraFollow` à câmera.
6. Para moedas, crie objetos com Collider marcado como `Is Trigger` e adicione `Coin`.
7. Para obstáculos, use objetos com Collider e adicione `Obstacle`.
8. Adicione `GameManager` a um objeto vazio chamado `GameManager`.
9. Adicione `LaneSpawner` a um objeto vazio. Configure prefabs de moedas e obstáculos no Inspector.
10. No Unity, selecione Android em Build Profiles/Build Settings e configure o Android Build Support para gerar um APK.

## Controles
- **A / D** ou **← / →**: mudar de faixa
- **W / Espaço / ↑**: pular
- **S / ↓**: deslizar
- **Android**: deslize para esquerda/direita/cima/baixo na tela

## Estrutura
```text
Zurich-Surfers/
├── Assets/
│   └── Scripts/
│       ├── PlayerRunner.cs
│       ├── CameraFollow.cs
│       ├── GameManager.cs
│       ├── Coin.cs
│       ├── Obstacle.cs
│       └── LaneSpawner.cs
├── .gitignore
├── LICENSE
└── README.md
```

## Nota sobre originalidade
Este projeto usa apenas a ideia geral de um jogo endless runner. Crie seus próprios personagens, cenário, sons, logotipo e interface. Não inclui nem reproduz personagens, mapas, músicas ou arquivos proprietários de Subway Surfers.
