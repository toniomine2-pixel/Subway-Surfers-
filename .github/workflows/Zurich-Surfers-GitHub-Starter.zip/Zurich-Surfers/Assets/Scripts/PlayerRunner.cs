using UnityEngine;

/// <summary>
/// Core endless-runner controller: automatic forward motion, three lanes,
/// jump/slide, keyboard testing and touch-swipe input.
/// Requires a CharacterController on the same GameObject.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerRunner : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float forwardSpeed = 9f;
    [SerializeField] private float laneWidth = 2.5f;
    [SerializeField] private float laneChangeSpeed = 12f;
    [SerializeField] private float jumpHeight = 2.2f;
    [SerializeField] private float gravity = -24f;

    [Header("Slide")]
    [SerializeField] private float slideDuration = 0.7f;
    [SerializeField] private float slideHeight = 1f;

    private CharacterController controller;
    private int lane = 1; // 0 = left, 1 = center, 2 = right
    private float verticalVelocity;
    private float normalHeight;
    private Vector3 normalCenter;
    private float slideTimer;
    private Vector2 touchStart;
    private bool touchStarted;

    public bool IsAlive { get; private set; } = true;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        normalHeight = controller.height;
        normalCenter = controller.center;
    }

    private void Update()
    {
        if (!IsAlive) return;

        ReadInput();
        MoveRunner();
    }

    private void ReadInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
            ChangeLane(-1);
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
            ChangeLane(1);
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow) ||
            Input.GetKeyDown(KeyCode.W))
            Jump();
        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S))
            Slide();

        // Basic touch-swipe support for Android.
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began)
            {
                touchStart = touch.position;
                touchStarted = true;
            }
            else if (touchStarted &&
                     (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled))
            {
                Vector2 delta = touch.position - touchStart;
                touchStarted = false;
                if (delta.magnitude < 55f) return;

                if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y))
                    ChangeLane(delta.x > 0 ? 1 : -1);
                else if (delta.y > 0)
                    Jump();
                else
                    Slide();
            }
        }
    }

    private void MoveRunner()
    {
        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;

        verticalVelocity += gravity * Time.deltaTime;

        Vector3 target = transform.position;
        target.x = (lane - 1) * laneWidth;
        float lateral = (target.x - transform.position.x) * laneChangeSpeed;
        Vector3 movement = new Vector3(lateral, verticalVelocity, forwardSpeed);
        controller.Move(movement * Time.deltaTime);

        if (slideTimer > 0f)
        {
            slideTimer -= Time.deltaTime;
            if (slideTimer <= 0f) RestoreCollider();
        }
    }

    public void ChangeLane(int direction)
    {
        lane = Mathf.Clamp(lane + direction, 0, 2);
    }

    public void Jump()
    {
        if (controller.isGrounded && slideTimer <= 0f)
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
    }

    public void Slide()
    {
        if (!controller.isGrounded || slideTimer > 0f) return;
        slideTimer = slideDuration;
        controller.height = slideHeight;
        controller.center = new Vector3(normalCenter.x, slideHeight * 0.5f, normalCenter.z);
    }

    private void RestoreCollider()
    {
        controller.height = normalHeight;
        controller.center = normalCenter;
        slideTimer = 0f;
    }

    public void Die()
    {
        if (!IsAlive) return;
        IsAlive = false;
        GameManager manager = FindObjectOfType<GameManager>();
        if (manager != null) manager.EndRun();
    }
}
