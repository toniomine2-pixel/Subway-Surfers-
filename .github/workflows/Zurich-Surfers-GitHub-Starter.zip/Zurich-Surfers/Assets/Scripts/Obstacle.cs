using UnityEngine;

/// <summary>Attach to an obstacle or train with a Collider.</summary>
public class Obstacle : MonoBehaviour
{
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        PlayerRunner player = hit.controller.GetComponent<PlayerRunner>();
        if (player != null) player.Die();
    }

    private void OnTriggerEnter(Collider other)
    {
        PlayerRunner player = other.GetComponent<PlayerRunner>();
        if (player == null) player = other.GetComponentInParent<PlayerRunner>();
        if (player != null) player.Die();
    }
}
