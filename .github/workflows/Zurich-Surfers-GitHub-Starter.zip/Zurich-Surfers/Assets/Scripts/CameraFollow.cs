using UnityEngine;

/// <summary>Simple smooth third-person follow camera.</summary>
public class CameraFollow : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 5f, -8f);
    [SerializeField] private float smoothSpeed = 8f;
    [SerializeField] private Vector3 lookOffset = new Vector3(0f, 1.4f, 3f);

    private void LateUpdate()
    {
        if (target == null) return;
        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, smoothSpeed * Time.deltaTime);
        transform.LookAt(target.position + lookOffset);
    }

    public void SetTarget(Transform newTarget) => target = newTarget;
}
