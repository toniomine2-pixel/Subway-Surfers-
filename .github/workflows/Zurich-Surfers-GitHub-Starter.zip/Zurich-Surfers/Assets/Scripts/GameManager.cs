using UnityEngine;
using UnityEngine.UI;

/// <summary>Tracks score, collected coins, and run state.</summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [SerializeField] private Text scoreText;
    [SerializeField] private Text coinText;
    [SerializeField] private GameObject gameOverPanel;

    public int Coins { get; private set; }
    public int Score { get; private set; }
    public bool IsGameOver { get; private set; }

    private Transform player;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    private void Start()
    {
        PlayerRunner runner = FindObjectOfType<PlayerRunner>();
        if (runner != null) player = runner.transform;
        RefreshUI();
    }

    private void Update()
    {
        if (IsGameOver) return;
        if (player != null) Score = Mathf.Max(Score, Mathf.FloorToInt(player.position.z));
        RefreshUI();
    }

    public void AddCoin(int amount = 1)
    {
        if (IsGameOver) return;
        Coins += Mathf.Max(0, amount);
        RefreshUI();
    }

    public void EndRun()
    {
        if (IsGameOver) return;
        IsGameOver = true;
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
        RefreshUI();
    }

    public void RestartRun()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
    }

    private void RefreshUI()
    {
        if (scoreText != null) scoreText.text = "Distância: " + Score;
        if (coinText != null) coinText.text = "Moedas: " + Coins;
    }
}
