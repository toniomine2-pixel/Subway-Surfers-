using UnityEngine;

/// <summary>Collectible coin. Use a Collider with Is Trigger enabled.</summary>
public class Coin : MonoBehaviour
{
    [SerializeField] private int value = 1;
    [SerializeField] private float spinSpeed = 140f;

    private void Update()
    {
        transform.Rotate(0f, spinSpeed * Time.deltaTime, 0f, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        PlayerRunner player = other.GetComponent<PlayerRunner>();
        if (player == null) player = other.GetComponentInParent<PlayerRunner>();
        if (player == null) return;

        GameManager manager = GameManager.Instance;
        if (manager != null) manager.AddCoin(value);
        Destroy(gameObject);
    }
}
