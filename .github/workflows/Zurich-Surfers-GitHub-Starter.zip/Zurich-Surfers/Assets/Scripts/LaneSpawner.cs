using UnityEngine;

/// <summary>
/// Spawns simple obstacle/coin prefabs ahead of the player.
/// Assign prefabs in the Inspector. Prefabs should face the +Z direction.
/// </summary>
public class LaneSpawner : MonoBehaviour
{
    [SerializeField] private Transform player;
    [SerializeField] private GameObject[] obstaclePrefabs;
    [SerializeField] private GameObject coinPrefab;
    [SerializeField] private float laneWidth = 2.5f;
    [SerializeField] private float spawnAhead = 45f;
    [SerializeField] private float spawnInterval = 1.3f;
    [SerializeField] private float cleanupBehind = 18f;
    [Range(0f, 1f)]
    [SerializeField] private float coinChance = 0.55f;

    private float timer;

    private void Start()
    {
        if (player == null)
        {
            PlayerRunner runner = FindObjectOfType<PlayerRunner>();
            if (runner != null) player = runner.transform;
        }
    }

    private void Update()
    {
        if (player == null || (GameManager.Instance != null && GameManager.Instance.IsGameOver))
            return;

        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            timer = 0f;
            SpawnRow();
        }

        // Keep the scene lightweight by deleting objects that have fallen far behind.
        GameObject[] spawned = GameObject.FindGameObjectsWithTag("SpawnedRunnerObject");
        foreach (GameObject item in spawned)
        {
            if (item.transform.position.z < player.position.z - cleanupBehind)
                Destroy(item);
        }
    }

    private void SpawnRow()
    {
        int lane = Random.Range(0, 3);
        float x = (lane - 1) * laneWidth;
        Vector3 position = new Vector3(x, 0.5f, player.position.z + spawnAhead);

        bool spawnCoin = coinPrefab != null && Random.value < coinChance;
        GameObject prefab = spawnCoin ? coinPrefab : GetObstaclePrefab();
        if (prefab == null) return;

        GameObject spawned = Instantiate(prefab, position, prefab.transform.rotation);
        // Add this tag in Unity's Tags & Layers if it does not already exist.
        // If the tag is missing, cleanup is safely skipped.
        try { spawned.tag = "SpawnedRunnerObject"; }
        catch (UnityException) { }
    }

    private GameObject GetObstaclePrefab()
    {
        if (obstaclePrefabs == null || obstaclePrefabs.Length == 0) return null;
        return obstaclePrefabs[Random.Range(0, obstaclePrefabs.Length)];
    }
}
